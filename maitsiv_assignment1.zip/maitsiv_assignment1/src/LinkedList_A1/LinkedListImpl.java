/**
 * COMP 410
 *See inline comment descriptions for methods not described in interface.
 *
*/
package LinkedList_A1;

public class LinkedListImpl implements LIST_Interface {
  Node sentinel; //this will be the entry point to your linked list (the head)
  int numElts;
  
  
  public LinkedListImpl(){//this constructor is needed for testing purposes. Please don't modify!
    sentinel=new Node(0); //Note that the root's data is not a true part of your data set!
    this.numElts=0;
  }
  
  //implement all methods in interface, and include the getRoot method we made for testing purposes. Feel free to implement private helper methods!
  
  public Node getRoot(){ //leave this method as is, used by the grader to grab your linkedList easily.
    return sentinel;
  }

@Override
public boolean insert(double elt, int index) {
	Node newNode = new Node(elt);

	if (index > numElts || index < 0) {
		return false;	
	}	
	if (this.isEmpty()) {
		newNode.next = sentinel;
		sentinel.prev = newNode;
		sentinel.next = newNode;
		newNode.prev = sentinel;
		numElts++;
	} else {
	Node head = sentinel.next;
	Node current = head;	
		if (index == 0) {
			newNode.prev = sentinel;
			newNode.prev.next = newNode;
			newNode.next = current;
			current.prev = newNode;
			numElts++;
		} else {
			int count = 0;
			while (count < index -1) {
			current = current.next;
			count++;
		}
		if (index == numElts) {
			newNode.prev = current;
			newNode.next = sentinel;
			sentinel.prev = newNode;
			newNode.prev.next = newNode;
			numElts++;
		} else {
		newNode.next = current.next;
		newNode.next.prev = newNode;
		newNode.prev = current;
		current.next = newNode;
		numElts++;
		}
		return true;
	}
	}
	return true;
}

@Override
public boolean remove(int index) {
	if (index > this.size()-1 || index < 0) {
		return false;
	}
	
	if (this.isEmpty()) {
		return false;
	}
	Node head = this.sentinel.next;
	Node current = head;
		
	int count = 0;
	while (count < index) {
			current = current.next;
			count++;
		
	}
	
	current.prev.next = current.next;
	current.next.prev = current.prev;
	current.next.prev.next = current.next;
	current.prev.next.prev = current.prev;
	numElts--;

	return true;
}

@Override
public double get(int index) {
	Node head = this.sentinel.next;
	Node current = head;
	if (index >= numElts || index < 0) {
		return Double.NaN;
	}
	for (int i = 0; i < index; i++) {
		current = current.next;		
	}
	return current.data;
}

@Override
public int size() {	
	return numElts;
}

@Override
public boolean isEmpty() {
	if ((sentinel.next == sentinel) || (sentinel.next == null)) {
		return true;
	}
	if (this.size() == 0) {
		return true;
	}
	return false;
}

@Override
public void clear() {
	sentinel.next = sentinel;
	sentinel.prev = sentinel;
	sentinel.next.prev = sentinel;
	numElts = 0;	
	
}

}
